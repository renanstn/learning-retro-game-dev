NSTssTXT

BtnTiles=1
BtnChecker=0
BtnSelTiles=0
BtnChrBank1=1
BtnChrBank2=0
BtnGridAll=0
BtnGridTile=0
BtnGridAtr=1
BtnGridBlock=0
BtnPal=1
BtnTypeIn=0
BtnFrameAll=1
BtnFrameSelected=0
BtnFrameNone=0
BtnSpriteSnap=0
BtnSprite8x16=0
MenuBestOffsets=0
MenuLossy=0
MenuThreshold=0
MenuNoColorData=0
MenuMetaSprAutoInc=0
MenuMetaSprSkipZero=0
MenuMetaSprMerge=0
MenuSaveIncName=1
MenuSaveIncAttr=1
MenuSaveRLE=0
VarBgPalCur=3
VarPalActive=0
VarTileActive=244
VarBankActive=0
VarPPUMask=0
VarPPUMaskSet0=0
VarPPUMaskSet1=0
VarPPUMaskSet2=0
VarPPUMaskSet3=0
VarPalBank=0
VarMetaSpriteActive=0
VarSpriteActive=0
VarSpriteGridX=64
VarSpriteGridY=64
VarNameW=32
VarNameH=30
VarNameViewX=0
VarNameViewY=-1
VarNameSelectionL=-1
VarNameSelectionR=1
VarNameSelectionT=-1
VarNameSelectionB=1
VarNameCopyW=32
VarNameCopyH=30
VarCHRSelectionL=4
VarCHRSelectionR=5
VarCHRSelectionT=15
VarCHRSelectionB=16
VarCHRCopyW=1
VarCHRCopyH=1
VarCHRCopyRect=1
VarCHRSelectRect=1


VarCHRSelected=00[f4]0100[b]


Palette=0f0010300f0121310f0616260f0919290f1121310f1222320f1323330f1424340f1525350f1626360f1727370f1828380f1929390f1a2a3a0f1b2b3b0f1c2c3c


PalUndo=0f0010300f0121310f0616260f0919290f1121310f1222320f1323330f1424340f1525350f1626360f1727370f1828380f1929390f1a2a3a0f1b2b3b0f1c2c3c


CHRMain=00[c01]7e[2]6e[2]7e[2]00[2]7e[2]6e[2]7e[2]00[2]3c7c3c[4]00[2]3c7c3c[4]00[2]7e6e0e7e607e00[2]7e6e0e7e607e00[2]7e0e3e[2]0e7e00[2]7e0e3e[2]0e7e00[2]6e[3]7e0e[2]00[2]6e[3]7e0e[2]00[2]7e607e0e6e7e00[2]7e607e0e6e7e00[2]7e607e6e[2]7e00[2]7e607e6e[2]7e00[2]7e6e0e[4]00[2]7e6e0e[4]00[2]7e6e3c6e[2]7e00[2]7e6e3c6e[2]7e00[2]7e6e[2]7e0e[2]00[2]7e6e[2]7e0e[2]00[2]7e6e[2]7e6e[2]00[2]7e6e[2]7e6e[2]00[2]7c6e7c6e[2]7c00[2]7c6e7c6e[2]7c00[2]7e6e606e[2]7e00[2]7e6e606e[2]7e00[2]7c6e[4]7c00[2]7c6e[4]7c00[2]7e707c[2]707e00[2]7e707c[2]707e00[2]7e76707870[2]00[2]7e76707870[2]00[2]7e6e606f6e7e00[2]7e6e606f6e7e00[2]6e[3]7e6e[2]00[2]6e[3]7e6e[2]00[2]7e3c[4]7e00[2]7e3c[4]7e00[2]0e[5]7c00[2]0e[5]7c00[2]6e[2]787c6e[2]00[2]6e[2]787c6e[2]00[2]70[5]7e00[2]70[5]7e00[2]6e7e[2]6e[3]00[2]6e7e[2]6e[3]00[2]4e6e7e[2]6e6600[2]4e6e7e[2]6e6600[2]7e6e[4]7e00[2]7e6e[4]7e00[2]7c76[3]7c7000[2]7c76[3]7c7000[2]7e6e[4]7e0f007e6e[4]7e0f007c76[2]7c76[2]00[2]7c76[2]7c76[2]00[2]7e607e0e[2]7e00[2]7e607e0e[2]7e00[2]fe38[5]00[2]fe38[5]00[2]6e[5]7e00[2]6e[5]7e00[2]6e[3]3c[3]00[2]6e[3]3c[3]00[2]6e[2]7e[3]6e00[2]6e[2]7e[3]6e00[2]6e7c383c6e[2]00[2]6e7c383c6e[2]00[2]6e[2]3c18[3]00[2]6e[2]3c18[3]00[2]7e6e1c38767e00[2]7e6e1c38767e00[6]70[2]00[6]70[2]00[6]70[2]1000[5]70[2]100070[2]00[2]70[2]00[2]70[2]00[2]70[2]00[2]7e660c[2]000c00[2]7e660c[2]000c00[2]38[4]003800[2]38[4]003800[2]ee[2]2200[5]ee[2]2200[5]e0[2]2000[5]e0[2]2000[5]1c[2]38[2]70[2]00[2]1c[2]38[2]70[2]00[2]1c38[4]1c00[2]1c38[4]1c00[2]7038[4]7000[2]7038[4]7000[2]7c60667f667600[2]7c60667f667600[2]6cfe6c[2]fe6c00[2]6cfe6c[2]fe6c00[2]18[2]7e[2]18[2]00[2]18[2]7e[2]18[2]00[4]7c[2]00[6]7c[2]00[4]3c38[4]3c00[2]3c38[4]3c00[2]7838[4]7800[2]7838[4]7800[2]6cfe[2]7c381000[2]6cfe[2]7c381000[2]18[2]66[2]18[2]00[2]18[2]66[2]18[2]00[2]70[2]00[2]70[2]100070[2]00[2]70[2]1000[5]ee[2]00[6]ee[2]00[5]38283800[5]38283800[6]0c1800[6]0c1800[6]6c3800[6]6c3800[7]7c00[7]7c003c4299a5adb542383c4299a5adb542383c4299a1[2]99423c[2]4299a1[2]99423c00e94f49[2]00[4]e94f49[2]00[4]6cacd81b353600[2]6cacd81b353600[1001]


CHRCopy=006cfe[2]7c381000[2]6cfe[2]7c3810003c7cfc3c[4]003c7cfc3c[4]00fee6063ee0eefe00fee6063ee0eefe00feee0e3e0eeefe00feee0e3e0eeefe00ee[4]fe0e[2]00ee[4]fe0e[2]00fee0[2]fe0e[2]fe00fee0[2]fe0e[2]fe00fee0[2]fee6[2]fe00fee0[2]fee6[2]fe00feee0e[5]00feee0e[5]00feee[2]7cee[2]fe00feee[2]7cee[2]fe00feee[2]fe0e[3]00feee[2]fe0e[3]00feee[3]feee[2]00feee[3]feee[2]00fcee[2]fcee[2]fc00fcee[2]fcee[2]fc00feee[2]e0ee[2]fe00feee[2]e0ee[2]fe00fcee[5]fc00fcee[5]fc00feeee0f8e0eefe00feeee0f8e0eefe00feeee0f8e0[3]00feeee0f8e0[3]00feeee0efee[2]fe00feeee0efee[2]fe00ee[3]feee[3]00ee[3]feee[3]00fe7c[5]fe00fe7c[5]fe001e[6]fc001e[6]fc00ee[2]fcf8fcee[2]00ee[2]fcf8fcee[2]00f0[6]fe00f0[6]fe00eefe[3]ee[3]00eefe[3]ee[3]00ceeefe[3]eee600ceeefe[3]eee600feee[5]fe00feee[5]fe00fcee[3]fce0[2]00fcee[3]fce0[2]00feee[5]fe0ffeee[5]fe0ffcee[2]fcee[3]00fcee[2]fcee[3]00feeee0fe0eeefe00feeee0fe0eeefe00fe38[6]00fe38[6]00ee[6]fe00ee[6]fe00ee[4]7c[3]00ee[4]7c[3]00ee[3]fe[3]ee00ee[3]fe[3]ee00ee[2]7c387cee[2]00ee[2]7c387cee[2]00ee[3]7c38[3]00ee[3]7c38[3]00feee1c3870eefe00feee1c3870eefe00[6]70[2]00[6]70[2]00[6]70[2]1000[5]70[2]100070[2]00[2]70[2]00[2]70[2]00[2]70[2]00feee0e1c[2]001c00feee0e1c[2]001c0038[5]00380038[5]003800ee[2]2200[5]ee[2]2200[5]e0[2]2000[5]e0[2]2000[5]1c[2]38[3]70[2]001c[2]38[3]70[2]001c38[5]1c001c38[5]1c007038[5]70007038[5]7000fce0e6ffe6[2]f600fce0e6ffe6[2]f6006cfe6c[3]fe6c006cfe6c[3]fe6c00[2]38[2]fe[2]38[2]00[2]38[2]fe[2]38[2]00[4]fc[2]00[6]fc[2]00[3]3c38[5]3c003c38[5]3c007838[5]78007838[5]7800[2]6cfe[2]7c381000[2]6cfe[2]7c381000[2]18[2]66[2]18[2]00[2]18[2]66[2]18[2]00[2]70[2]00[2]70[2]100070[2]00[2]70[2]1000[5]ee[2]00[6]ee[2]00[5]38283800[5]38283800[6]0c1800[6]0c1800[6]6c3800[6]6c3800[7]7c00[7]7c003c4299a5adb542383c4299a5adb542383c4299a1[2]99423c[2]4299a1[2]99423c00e94f49[2]00[4]e94f49[2]00[3]6cacd8181b3536006cacd8181b353600[2]18[2]66[2]18[2]00[2]18[2]66[2]18[2]00[2]60[2]0060[2]20400060[2]0060[2]204000[5]6c[2]00[6]6c[2]00[5]38283800[5]38283800[6]0c1800[6]0c1800[6]6c3800[6]6c3800[7]7c00[7]7c003c4299a5adb542383c4299a5adb542383c4299a1[2]99423c[2]4299a1[2]99423c00e94f49[2]00[4]e94f49[2]00[3]6cacd8181b3536006cacd8181b353600[b51]


CHRUndo=00[c01]7e[2]6e[2]7e[2]00[2]7e[2]6e[2]7e[2]00[2]3c7c3c[4]00[2]3c7c3c[4]00[2]7e6e0e7e607e00[2]7e6e0e7e607e00[2]7e0e3e[2]0e7e00[2]7e0e3e[2]0e7e00[2]6e[3]7e0e[2]00[2]6e[3]7e0e[2]00[2]7e607e0e6e7e00[2]7e607e0e6e7e00[2]7e607e6e[2]7e00[2]7e607e6e[2]7e00[2]7e6e0e[4]00[2]7e6e0e[4]00[2]7e6e3c6e[2]7e00[2]7e6e3c6e[2]7e00[2]7e6e[2]7e0e[2]00[2]7e6e[2]7e0e[2]00[2]7e6e[2]7e6e[2]00[2]7e6e[2]7e6e[2]00[2]7c6e7c6e[2]7c00[2]7c6e7c6e[2]7c00[2]7e6e606e[2]7e00[2]7e6e606e[2]7e00[2]7c6e[4]7c00[2]7c6e[4]7c00[2]7e707c[2]707e00[2]7e707c[2]707e00[2]7e76707870[2]00[2]7e76707870[2]00[2]7e6e606f6e7e00[2]7e6e606f6e7e00[2]6e[3]7e6e[2]00[2]6e[3]7e6e[2]00[2]7e3c[4]7e00[2]7e3c[4]7e00[2]0e[5]7c00[2]0e[5]7c00[2]6e[2]787c6e[2]00[2]6e[2]787c6e[2]00[2]70[5]7e00[2]70[5]7e00[2]6e7e[2]6e[3]00[2]6e7e[2]6e[3]00[2]4e6e7e[2]6e6600[2]4e6e7e[2]6e6600[2]7e6e[4]7e00[2]7e6e[4]7e00[2]7c76[3]7c7000[2]7c76[3]7c7000[2]7e6e[4]7e0f007e6e[4]7e0f007c76[2]7c76[2]00[2]7c76[2]7c76[2]00[2]7e607e0e[2]7e00[2]7e607e0e[2]7e00[2]fe38[5]00[2]fe38[5]00[2]6e[5]7e00[2]6e[5]7e00[2]6e[3]3c[3]00[2]6e[3]3c[3]00[2]6e[2]7e[3]6e00[2]6e[2]7e[3]6e00[2]6e7c383c6e[2]00[2]6e7c383c6e[2]00[2]6e[2]3c18[3]00[2]6e[2]3c18[3]00[2]7e6e1c38767e00[2]7e6e1c38767e00[6]70[2]00[6]70[2]00[6]70[2]1000[5]70[2]100070[2]00[2]70[2]00[2]70[2]00[2]70[2]00[2]7e660c[2]000c00[2]7e660c[2]000c00[2]38[4]003800[2]38[4]003800[2]ee[2]2200[5]ee[2]2200[5]e0[2]2000[5]e0[2]2000[5]1c[2]38[2]70[2]00[2]1c[2]38[2]70[2]00[2]1c38[4]1c00[2]1c38[4]1c00[2]7038[4]7000[2]7038[4]7000[2]7c60667f667600[2]7c60667f667600[2]6cfe6c[2]fe6c00[2]6cfe6c[2]fe6c00[2]18[2]7e[2]18[2]00[2]18[2]7e[2]18[2]00[4]7c[2]00[6]7c[2]00[4]3c38[4]3c00[2]3c38[4]3c00[2]7838[4]7800[2]7838[4]7800[2]6cfe[2]7c381000[2]6cfe[2]7c381000[2]18[2]66[2]18[2]00[2]18[2]66[2]18[2]00[2]70[2]00[2]70[2]100070[2]00[2]70[2]1000[5]ee[2]00[6]ee[2]00[5]38283800[5]38283800[6]0c1800[6]0c1800[6]6c3800[6]6c3800[7]7c00[7]7c003c4299a5adb542383c4299a5adb542383c4299a1[2]99423c[2]4299a1[2]99423c00e94f49[2]00[4]e94f49[2]00[4]6cacd81b353600[2]6cacd81b353600[1001]


NameTable=00[a6]ddd1ce00daded2ccd400cbdbd8e0d720cfd8e100[2b]d3ded6d9dc20d8dfcedb20ddd1ce20d5cae3e220cdd8d0e400[88]dcd9d1d2d7e120d8cf2000cbd5caccd420dadecadbdde3e500[2e]d3decdd0ce20d6e220dfd8e0e800[d1]c0c1c2c3c4c5c6c7c8c9cacbcccdcecf00[10]d0d1d2d3d4d5d6d7d8d9dadbdcdddedf00[10]e0e1e2e3e4e5e6e7e8e9eaebecedeeef00[10]f0f1f2f3f4f5f6f7f8f9fafbfcfdfeff00[a8]


NameCopy=00[a6]ddd1ce00daded2ccd400cbdbd8e0d720cfd8e100[2b]d3ded6d9dc20d8dfcedb20ddd1ce20d5cae3e220cdd8d0e400[88]dcd9d1d2d7e120d8cf2000cbd5caccd420dadecadbdde3e500[2e]d3decdd0ce20d6e220dfd8e0e800[d1]c0c1c2c3c4c5c6c7c8c9cacbcccdcecf00[10]d0d1d2d3d4d5d6d7d8d9dadbdcdddedf00[10]e0e1e2e3e4e5e6e7e8e9eaebecedeeef00[10]f0f1f2f3f4f5f6f7f8f9fafbfcfdfeff00[a8]


NameUndo=00[a6]ddd1ce00daded2ccd400cbdbd8e0d720cfd8e100[2b]d3ded6d9dc20d8dfcedb20ddd1ce20d5cae3e220cdd8d0e400[88]dcd9d1d2d7e120d8cf2000cbd5caccd420dadecadbdde3e500[2e]d3decdd0ce20d6e220dfd8e0e800[d1]c0c1c2c3c4c5c6c7c8c9cacbcccdcecf00[10]d0d1d2d3d4d5d6d7d8d9dadbdcdddedf00[10]e0e1e2e3e4e5e6e7e8e9eaebecedeeef00[10]f0f1f2f3f4f5f6f7f8f9fafbfcfdfeff00[a8]


AttrTable=00[40]


AttrCopy=00[40]


AttrUndo=00[40]


MetaSprites=ff[10000]


Checkpoint_Palette=00[40]


Checkpoint_PalUndo=00[40]


Checkpoint_CHRMain=00[2000]


Checkpoint_CHRUndo=00[2000]


Checkpoint_NameTable=00[3c0]


Checkpoint_NameUndo=00[3c0]


Checkpoint_AttrTable=00[40]


Checkpoint_AttrUndo=00[40]


Checkpoint_MetaSprites=00[10000]
MetaSpriteBankName=session

FilterCHR=0
FilterName=1
FileNameCHR=
FileNameName=
FileNamePal=
FileNameMetaSpriteBank=
