object FormFader: TFormFader
  Left = 0
  Top = 0
  BorderStyle = bsToolWindow
  Caption = 
    'Fader | Metapalette Table Editor [Secret preview - only partly w' +
    'orking]'
  ClientHeight = 228
  ClientWidth = 1028
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
  object PaintBoxFader: TPaintBox
    Left = 2
    Top = 2
    Width = 1024
    Height = 136
    OnPaint = PaintBoxFaderPaint
  end
  object PaintBoxSys: TPaintBox
    Left = 360
    Top = 144
    Width = 256
    Height = 64
    Color = clBtnFace
    ParentColor = False
    OnPaint = PaintBoxSysPaint
  end
  object PaintBoxSubpal: TPaintBox
    Left = 624
    Top = 144
    Width = 180
    Height = 32
    OnPaint = PaintBoxSubpalPaint
  end
  object Label1: TLabel
    Left = 360
    Top = 210
    Width = 87
    Height = 13
    Caption = 'meta colour picker'
  end
  object GroupBox1: TGroupBox
    Left = 2
    Top = 139
    Width = 136
    Height = 87
    Caption = 'Preview on'
    TabOrder = 0
    object CheckBox1: TCheckBox
      Left = 8
      Top = 13
      Width = 40
      Height = 17
      TabStop = False
      Caption = 'BG'
      TabOrder = 0
    end
    object CheckBox2: TCheckBox
      Left = 8
      Top = 29
      Width = 116
      Height = 17
      TabStop = False
      Caption = 'Main editor palettes'
      TabOrder = 1
    end
    object CheckBox3: TCheckBox
      Left = 48
      Top = 13
      Width = 40
      Height = 17
      TabStop = False
      Caption = 'Spr'
      TabOrder = 2
    end
    object CheckBox4: TCheckBox
      Left = 88
      Top = 13
      Width = 40
      Height = 17
      TabStop = False
      Caption = 'CHR'
      TabOrder = 3
    end
    object CheckBox5: TCheckBox
      Left = 8
      Top = 46
      Width = 124
      Height = 17
      TabStop = False
      Caption = 'Meta Colour Picker'
      TabOrder = 4
    end
    object CheckBox9: TCheckBox
      Left = 8
      Top = 63
      Width = 110
      Height = 17
      TabStop = False
      Caption = 'Exported Images'
      TabOrder = 5
    end
  end
  object GroupBox2: TGroupBox
    Left = 140
    Top = 139
    Width = 170
    Height = 87
    Caption = 'Fader '
    TabOrder = 1
    object Label2: TLabel
      Left = 132
      Top = 40
      Width = 21
      Height = 11
      Caption = 'steps'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -9
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object TrackBarMain: TTrackBar
      Left = 2
      Top = 14
      Width = 128
      Height = 30
      Max = 5
      TabOrder = 0
      TabStop = False
      OnChange = TrackBarMainChange
    end
    object Edit1: TEdit
      Left = 128
      Top = 17
      Width = 20
      Height = 19
      TabStop = False
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -9
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
      TabOrder = 1
      Text = '6'
    end
    object UpDown1: TUpDown
      Left = 148
      Top = 17
      Width = 14
      Height = 19
      Associate = Edit1
      Min = 2
      Max = 24
      Position = 6
      TabOrder = 2
      OnClick = UpDown1Click
    end
  end
  object GroupBox3: TGroupBox
    Left = 624
    Top = 182
    Width = 180
    Height = 44
    Caption = 'Subpal channels (1-4) | Set (A-B)'
    TabOrder = 2
    object SpeedButton1: TSpeedButton
      Left = 8
      Top = 16
      Width = 38
      Height = 20
      GroupIndex = 1
      Down = True
      Caption = 'All'
    end
    object SpeedButton2: TSpeedButton
      Left = 49
      Top = 16
      Width = 24
      Height = 20
      GroupIndex = 1
      Caption = '1'
    end
    object SpeedButton3: TSpeedButton
      Left = 75
      Top = 16
      Width = 24
      Height = 20
      GroupIndex = 1
      Caption = '2'
    end
    object SpeedButton4: TSpeedButton
      Left = 101
      Top = 16
      Width = 24
      Height = 20
      GroupIndex = 1
      Caption = '3'
    end
    object SpeedButton5: TSpeedButton
      Left = 127
      Top = 16
      Width = 24
      Height = 20
      GroupIndex = 1
      Caption = '4'
    end
    object SpeedButton6: TSpeedButton
      Left = 154
      Top = 16
      Width = 20
      Height = 20
      GroupIndex = 2
      Caption = 'A'
    end
  end
  object GroupBox4: TGroupBox
    Left = 312
    Top = 139
    Width = 40
    Height = 87
    Caption = 'PPUM'
    TabOrder = 3
    object ChkG: TCheckBox
      Left = 8
      Top = 29
      Width = 28
      Height = 17
      Caption = 'G'
      TabOrder = 0
      OnClick = ChkGClick
    end
    object ChkR: TCheckBox
      Left = 8
      Top = 13
      Width = 28
      Height = 17
      TabStop = False
      Caption = 'R'
      TabOrder = 1
      OnClick = ChkRClick
    end
    object ChkB: TCheckBox
      Left = 8
      Top = 46
      Width = 28
      Height = 17
      Caption = 'B'
      TabOrder = 2
      OnClick = ChkBClick
    end
    object ChkM: TCheckBox
      Left = 8
      Top = 63
      Width = 28
      Height = 17
      TabStop = False
      Caption = 'M'
      TabOrder = 3
      OnClick = ChkMClick
    end
  end
  object GroupBox5: TGroupBox
    Left = 932
    Top = 139
    Width = 94
    Height = 87
    Caption = 'Colour ID page'
    TabOrder = 4
    object SpeedButton7: TSpeedButton
      Left = 62
      Top = 60
      Width = 28
      Height = 22
      Caption = 'off'
    end
    object Radio00: TRadioButton
      Left = 8
      Top = 13
      Width = 78
      Height = 17
      Caption = '00-3F (NES)'
      TabOrder = 0
      OnClick = Radio00Click
    end
    object Radio40: TRadioButton
      Left = 8
      Top = 29
      Width = 50
      Height = 17
      Caption = '40-7F'
      TabOrder = 1
      OnClick = Radio00Click
    end
    object Radio80: TRadioButton
      Left = 8
      Top = 46
      Width = 50
      Height = 17
      Caption = '80-BF'
      TabOrder = 2
      OnClick = Radio00Click
    end
    object RadioC0: TRadioButton
      Left = 8
      Top = 63
      Width = 50
      Height = 17
      Caption = 'C0-FF'
      TabOrder = 3
      OnClick = Radio00Click
    end
    object StaticText1: TStaticText
      Left = 59
      Top = 37
      Width = 55
      Height = 15
      Alignment = taRightJustify
      Caption = '0-ff pal edits'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -9
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
      TabOrder = 4
    end
  end
end
