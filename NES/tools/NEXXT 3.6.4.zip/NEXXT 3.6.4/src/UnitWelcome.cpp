//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "UnitWelcome.h"
#include "UnitMain.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFormWelcome *FormWelcome;
//---------------------------------------------------------------------------
__fastcall TFormWelcome::TFormWelcome(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFormWelcome::Button1Click(TObject *Sender)
{
	ShellExecute(NULL, "open", "https://ko-fi.com/frankengraphics", "", NULL, SW_RESTORE);
	
}
//---------------------------------------------------------------------------
void __fastcall TFormWelcome::Button2Click(TObject *Sender)
{
	ShellExecute(NULL, "open", "https://www.patreon.com/frankengraphics", "", NULL, SW_RESTORE);	
}
//---------------------------------------------------------------------------
void __fastcall TFormWelcome::FormCreate(TObject *Sender)
{
	StaticText2->Caption = AnsiString("")
	+ "- New feature: Sort windows/forms by size [Ctrl + W]"
	+ "\n"
	+ "\n- Metatiles now auto-repaired when changing tile order"
	+ "\n- Metatile tool: fixed cosmetic issues running on Wine"
	+ "\n"
	+ "\n- Bugfix: certain forms should no longer stay on top of other apps"
	+ "\n- Bugfix: State for Tileset buttons C && D now properly loaded from file"
	;

	StaticText3->Caption = AnsiString("")
	+ "- Preparations for the big next (v4.x) development cycle"
	+ "\n- 3.x is finally coming to an end. Maintenance updates may happen before 4.x is ready to launch."
	;

	StaticText1->Caption = AnsiString("Thanks for using NEXXT! It's free && open source.")
	+ "\nHowever, it takes lots of time to develop,"
	+ " which means i can't have a fulltime job and develop nexxt at the same time."
	+ "\n\nIf possible, consider donating on ko-fi or subscribing to my patreon to help."
	+ " Thanks!  /FrankenGraphics"
	;

	StaticText4->Caption = AnsiString("Thanks to Sarah Lynne, Broke studio,  Uncle Dan, && Sandy Morrison for pledging donations or joining patreon since last major update.")
	;
}
//---------------------------------------------------------------------------


void __fastcall TFormWelcome::FormClose(TObject *Sender,
      TCloseAction &Action)
{
	FormMain->CreateWelcomeConfig();
}
//---------------------------------------------------------------------------

void __fastcall TFormWelcome::Button3Click(TObject *Sender)
{
	FormWelcome->Close();	
}
//---------------------------------------------------------------------------

