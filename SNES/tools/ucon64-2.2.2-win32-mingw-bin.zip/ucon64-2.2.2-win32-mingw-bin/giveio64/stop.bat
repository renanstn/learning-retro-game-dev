@echo off
echo NOTE: This batch file must be run as Administrator.
sc stop giveio
sc delete giveio
pause
