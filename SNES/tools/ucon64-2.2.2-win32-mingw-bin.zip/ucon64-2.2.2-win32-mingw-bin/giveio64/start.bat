@echo off
echo NOTE: This batch file must be run as Administrator.
setlocal
goto start

:get_absolute_path
if %1. equ . goto :eof
if %2. equ . goto :eof
set %1=%~dpf2
goto :eof

:start
cd /d %~dp0
if not exist giveio.sys (
echo ERROR: giveio.sys does not exist in the current directory.
exit /b
)
call :get_absolute_path giveio_sys_path giveio.sys
sc create giveio type= kernel binpath= "%giveio_sys_path%"
sc start giveio
pause
